package com.leko.forge.types

import com.leko.forge.context.Context
import com.leko.forge.parser.ForgeParser
import com.leko.forge.symbol.SymbolTable

/**
 * javac's `Types` analog: operations *on* Type values (resolution from grammar
 * nodes, subtyping/assignability, member lookup) — as opposed to SymbolTable,
 * which tracks *what exists*. Registered once in Context and shared by every
 * phase that needs consistent type semantics (Enter, AttrEnter, CompletenessChecker,
 * ExprTypeChecker, and eventually codegen) — see the earlier discussion on why
 * this must be one shared service rather than being reimplemented per phase.
 */
class TypeMap private constructor(private val context: Context) {
    companion object {
        fun instance(context: Context): TypeMap =
            context.getServices(TypeMap::class) { TypeMap(context) }
    }

    private val symbolTable by lazy { SymbolTable.instance(context) }

    fun resolve(ctx: ForgeParser.TypeContext): Type = when (ctx) {
        is ForgeParser.IntTypeContext -> Type.IntType
        is ForgeParser.FloatTypeContext -> Type.FloatType
        is ForgeParser.BoolTypeContext -> Type.BoolType
        is ForgeParser.StrTypeContext -> Type.StrType
        is ForgeParser.ListTypeContext -> Type.ListType(resolve(ctx.type()))
        is ForgeParser.MapTypeContext -> Type.MapType(resolve(ctx.key), resolve(ctx.value))
        is ForgeParser.RecordTypeContext -> Type.RecordRef(ctx.name.text)
        is ForgeParser.OptionalTypeContext -> Type.OptionalType(resolve(ctx.ty))
        is ForgeParser.InnerTypeContext -> Type.InnerType(resolve(ctx.outer), ctx.inner.text)
        else -> Type.ErrorType
    }

    /** Structural equality; errors never cascade into a second diagnostic. */
    fun isSameType(a: Type, b: Type): Boolean {
        if (a == Type.ErrorType || b == Type.ErrorType) return true
        return a == b
    }

    /**
     * Minimal subtyping relation, intentionally small for now:
     * identity, and T <: T? (optional widening). Extend here once interface
     * nodes need to be treated as supertypes of their implementers.
     */
    fun isAssignable(from: Type, to: Type): Boolean {
        if (from == Type.ErrorType || to == Type.ErrorType) return true
        if (from == to) return true
        if (to is Type.OptionalType && isAssignable(from, to.inner)) return true
        if (from is Type.OptionalType && to is Type.OptionalType) return isAssignable(from.inner, to.inner)
        return false
    }

    fun fieldType(receiver: Type, fieldName: String): Type {
        val recordName = when (receiver) {
            is Type.RecordRef -> receiver.name
            is Type.OptionalType -> (receiver.inner as? Type.RecordRef)?.name
            else -> null
        } ?: return Type.ErrorType
        val record = symbolTable.records[recordName] ?: return Type.ErrorType
        return record.fields[fieldName] ?: Type.ErrorType
    }
}
