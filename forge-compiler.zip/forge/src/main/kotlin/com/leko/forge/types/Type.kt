package com.leko.forge.types

/**
 * Forge's internal type representation — what `type: ...` grammar nodes resolve to.
 * This is the thing shared by every phase (completeness checking, dependency
 * analysis, eventual codegen) via the TypeMap service, so they all agree on what
 * a type "is" rather than each re-deriving it independently.
 */
sealed class Type {
    object IntType : Type() { override fun toString() = "int" }
    object FloatType : Type() { override fun toString() = "float" }
    object BoolType : Type() { override fun toString() = "bool" }
    object StrType : Type() { override fun toString() = "str" }
    data class ListType(val element: Type) : Type() { override fun toString() = "list<$element>" }
    data class MapType(val key: Type, val value: Type) : Type() { override fun toString() = "map<$key, $value>" }

    /** Reference to a record, enum, interface node, or concrete node by name. */
    data class RecordRef(val name: String) : Type() { override fun toString() = name }
    data class OptionalType(val inner: Type) : Type() { override fun toString() = "$inner?" }
    data class InnerType(val outer: Type, val innerName: String) : Type() { override fun toString() = "$outer.$innerName" }

    /** Produced when resolution/checking already failed — propagates without cascading new errors. */
    object ErrorType : Type() { override fun toString() = "<error>" }

    /** Produced where inference intentionally gives up (e.g. unimplemented expression forms). */
    object UnknownType : Type() { override fun toString() = "<unknown>" }
}
