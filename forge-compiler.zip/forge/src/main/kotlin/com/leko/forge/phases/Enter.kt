package com.leko.forge.phases

import com.leko.forge.context.Context
import com.leko.forge.parser.ForgeParser
import com.leko.forge.symbol.*
import com.leko.forge.types.TypeMap
import com.leko.forge.util.Log
import com.leko.forge.util.SourceSpan

/**
 * Phase 1 — javac's `Enter` analog. Walks the root and populates SymbolTable with
 * every top-level declaration. Runs in two sub-passes because records/nodes can
 * reference each other regardless of which one is written first in the file:
 * pass 1 registers every *name*, pass 2 resolves *bodies* (field types, params,
 * impl relations) now that every name is guaranteed to already be visible.
 */
class Enter private constructor(private val context: Context) {
    companion object {
        fun instance(context: Context): Enter =
            context.getServices(Enter::class) { Enter(context) }
    }

    private val symbolTable = SymbolTable.instance(context)
    private val typeMap = TypeMap.instance(context)
    private val log = Log.instance(context)

    fun enter(root: ForgeParser.RootContext) {
        for (child in root.children.orEmpty()) {
            when (child) {
                is ForgeParser.RecordContext -> registerRecordName(child)
                is ForgeParser.EnumContext -> registerEnumName(child)
                is ForgeParser.InterfaceNodeContext -> registerInterface(child)
                is ForgeParser.ConcreteNodeContext -> registerConcreteNodeName(child)
                else -> {}
            }
        }

        for (child in root.children.orEmpty()) {
            when (child) {
                is ForgeParser.RecordContext -> resolveRecordFields(child)
                is ForgeParser.EnumContext -> resolveEnumItems(child)
                is ForgeParser.FunctionContext -> registerFunction(child)
                is ForgeParser.ConcreteNodeContext -> resolveConcreteNodeParamsAndImpls(child)
                is ForgeParser.NodeInterfaceImplContext -> registerImpl(child)
                else -> {}
            }
        }
    }

    private fun registerRecordName(ctx: ForgeParser.RecordContext) {
        val name = ctx.name.text
        if (symbolTable.records.containsKey(name)) {
            log.error(SourceSpan.of(ctx), "E001", "duplicate record '$name'")
            return
        }
        symbolTable.records[name] = RecordSymbol(name, linkedMapOf(), SourceSpan.of(ctx))
    }

    private fun resolveRecordFields(ctx: ForgeParser.RecordContext) {
        val sym = symbolTable.records[ctx.name.text] ?: return
        for (f in ctx.recordField()) {
            val fname = f.name.text
            if (sym.fields.containsKey(fname)) {
                log.error(SourceSpan.of(f), "E002", "duplicate field '$fname' in record '${sym.name}'")
                continue
            }
            sym.fields[fname] = typeMap.resolve(f.ty)
        }
    }

    private fun registerEnumName(ctx: ForgeParser.EnumContext) {
        val name = ctx.name.text
        if (symbolTable.enums.containsKey(name)) {
            log.error(SourceSpan.of(ctx), "E003", "duplicate enum '$name'")
            return
        }
        symbolTable.enums[name] = EnumSymbol(name, linkedMapOf(), SourceSpan.of(ctx))
    }

    private fun resolveEnumItems(ctx: ForgeParser.EnumContext) {
        val sym = symbolTable.enums[ctx.name.text] ?: return
        for (item in ctx.enumItem()) {
            val iname = item.name.text
            val params = item.parameter().map { it.name.text to typeMap.resolve(it.ty) }
            sym.items[iname] = EnumItemSymbol(iname, params)
        }
    }

    private fun registerFunction(ctx: ForgeParser.FunctionContext) {
        val receiver = ctx.receiver?.let { typeMap.resolve(it) }
        val params = ctx.parameter().map { it.name.text to typeMap.resolve(it.ty) }
        val returnType = typeMap.resolve(ctx.ty)
        symbolTable.functions += FunctionSymbol(
            name = ctx.name.text,
            receiver = receiver,
            params = params,
            returnType = returnType,
            external = ctx.external != null,
            span = SourceSpan.of(ctx)
        )
    }

    private fun registerInterface(ctx: ForgeParser.InterfaceNodeContext) {
        val name = ctx.name.text
        if (symbolTable.isNodeName(name)) {
            log.error(SourceSpan.of(ctx), "E004", "duplicate node name '$name'")
            return
        }
        symbolTable.interfaces[name] = InterfaceNodeSymbol(name, SourceSpan.of(ctx))
    }

    private fun registerConcreteNodeName(ctx: ForgeParser.ConcreteNodeContext) {
        val name = ctx.name.text
        if (symbolTable.isNodeName(name)) {
            log.error(SourceSpan.of(ctx), "E004", "duplicate node name '$name'")
            return
        }
        // params/impls filled in during pass 2 — types may reference records not yet visible here.
        symbolTable.concreteNodes[name] = ConcreteNodeSymbol(name, SourceSpan.of(ctx))
    }

    private fun resolveConcreteNodeParamsAndImpls(ctx: ForgeParser.ConcreteNodeContext) {
        val sym = symbolTable.concreteNodes[ctx.name.text] ?: return
        sym.params = ctx.parameter().map { it.name.text to typeMap.resolve(it.ty) }
        ctx.impls?.IDENT()?.forEach { sym.implements += it.text }
        for (ifaceName in sym.implements) {
            if (!symbolTable.interfaces.containsKey(ifaceName)) {
                log.error(SourceSpan.of(ctx), "E005", "'${sym.name}' implements unknown interface '$ifaceName'")
            }
        }
    }

    private fun registerImpl(ctx: ForgeParser.NodeInterfaceImplContext) {
        val nodeName = ctx.extended.text
        val ifaceName = ctx.iface.text
        val node = symbolTable.concreteNodes[nodeName]
        if (node == null) {
            log.error(SourceSpan.of(ctx), "E006", "'for $nodeName impl $ifaceName': unknown node '$nodeName'")
            return
        }
        if (!symbolTable.interfaces.containsKey(ifaceName)) {
            log.error(SourceSpan.of(ctx), "E005", "'$nodeName' implements unknown interface '$ifaceName'")
            return
        }
        node.implements += ifaceName
    }
}
