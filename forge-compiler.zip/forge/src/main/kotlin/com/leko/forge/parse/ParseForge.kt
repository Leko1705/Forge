package com.leko.forge.parse

import com.leko.forge.parser.ForgeLexer
import com.leko.forge.parser.ForgeParser
import org.antlr.v4.runtime.CharStreams
import org.antlr.v4.runtime.CommonTokenStream
import java.io.File

/**
 * Front door into the ANTLR-generated lexer/parser. Everything downstream of
 * this call (Enter, AttrEnter, CompletenessChecker, DependencyGraph, ...)
 * operates purely on the resulting parse tree / Context services — ANTLR
 * itself is not referenced again anywhere else in the pipeline.
 */
fun File.parseForge(): ForgeParser.RootContext {
    val input = CharStreams.fromFileName(this.path)
    val lexer = ForgeLexer(input)
    val tokens = CommonTokenStream(lexer)
    val parser = ForgeParser(tokens)
    return parser.root()
}
