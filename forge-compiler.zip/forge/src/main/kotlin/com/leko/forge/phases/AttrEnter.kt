package com.leko.forge.phases

import com.leko.forge.attr.*
import com.leko.forge.context.Context
import com.leko.forge.parser.ForgeParser
import com.leko.forge.symbol.SymbolTable
import com.leko.forge.types.TypeMap
import com.leko.forge.util.Log
import com.leko.forge.util.SourceSpan

/**
 * Phase 2 — javac's `MemberEnter` analog for attributes. Walks the root and
 * registers every syn/inh declaration and equation into AttributeTable, resolving
 * declared types via TypeMap. Runs after Enter, since it needs to already know
 * which interface/node names exist to validate `syn Iface.attr` / `syn Node(...).attr`
 * heads.
 *
 * Coherence rule enforced here (mirrors Rust: one impl per (trait item, type)):
 * a second `syn`/`inh` equation for the same (node, attrName) is a hard error,
 * not a silent override — see the earlier discussion on why silent override is
 * the wrong default for a plugin-extensible language.
 */
class AttrEnter private constructor(private val context: Context) {
    companion object {
        fun instance(context: Context): AttrEnter =
            context.getServices(AttrEnter::class) { AttrEnter(context) }
    }

    private val symbolTable = SymbolTable.instance(context)
    private val typeMap = TypeMap.instance(context)
    private val attributeTable = AttributeTable.instance(context)
    private val log = Log.instance(context)

    fun enter(root: ForgeParser.RootContext) {
        for (child in root.children.orEmpty()) {
            when (child) {
                is ForgeParser.SynIfaceDefContext -> registerSynRequirement(child)
                is ForgeParser.SynImplContext -> registerSynEquation(child)
                is ForgeParser.InhDefContext -> registerInhDeclaration(child)
                is ForgeParser.InhImplContext -> registerInhEquation(child)
                else -> {}
            }
        }
    }

    private fun registerSynRequirement(ctx: ForgeParser.SynIfaceDefContext) {
        val iface = ctx.iface.text
        if (!symbolTable.interfaces.containsKey(iface)) {
            log.error(SourceSpan.of(ctx), "E010", "'syn $iface.${ctx.attrName.text}': unknown interface '$iface'")
            return
        }
        val attrName = ctx.attrName.text
        val bucket = attributeTable.requirements.getOrPut(iface) { linkedMapOf() }
        if (bucket.containsKey(attrName)) {
            log.error(SourceSpan.of(ctx), "E011", "duplicate requirement '$iface.$attrName'")
            return
        }
        bucket[attrName] = SynRequirement(iface, attrName, typeMap.resolve(ctx.attrType), SourceSpan.of(ctx))
    }

    private fun registerSynEquation(ctx: ForgeParser.SynImplContext) {
        val nodeName = ctx.node.text
        if (!symbolTable.isNodeName(nodeName)) {
            log.error(SourceSpan.of(ctx), "E012", "'syn $nodeName(...).${ctx.attrName.text}': unknown node '$nodeName'")
            return
        }
        val attrName = ctx.attrName.text
        val bucket = attributeTable.synEquations.getOrPut(nodeName) { linkedMapOf() }
        if (bucket.containsKey(attrName)) {
            log.error(
                SourceSpan.of(ctx), "E013",
                "duplicate equation for '$nodeName.$attrName' " +
                "(add an explicit 'override' construct if this is an intentional refinement)"
            )
            return
        }
        bucket[attrName] = SynEquation(
            nodeName = nodeName,
            paramPatterns = ctx.simpleParameterPattern(),
            attrName = attrName,
            attrType = typeMap.resolve(ctx.attrType),
            body = ctx.syn,
            span = SourceSpan.of(ctx)
        )
    }

    private fun registerInhDeclaration(ctx: ForgeParser.InhDefContext) {
        val attrName = ctx.attrName.text
        if (attributeTable.inhDeclarations.containsKey(attrName)) {
            log.error(SourceSpan.of(ctx), "E014", "duplicate inherited attribute declaration '$attrName'")
            return
        }
        attributeTable.inhDeclarations[attrName] =
            InhDeclaration(attrName, typeMap.resolve(ctx.attrType), ctx.init, SourceSpan.of(ctx))
    }

    private fun registerInhEquation(ctx: ForgeParser.InhImplContext) {
        val attrName = ctx.attrName.text
        val nodeName = ctx.node.text
        if (!symbolTable.isNodeName(nodeName)) {
            log.error(SourceSpan.of(ctx), "E015", "'inh $attrName(...) -> $nodeName(...)': unknown node '$nodeName'")
            return
        }
        val bucket = attributeTable.inhEquations.getOrPut(attrName) { linkedMapOf() }
        if (bucket.containsKey(nodeName)) {
            log.error(SourceSpan.of(ctx), "E016", "duplicate inherited equation '$attrName' for node '$nodeName'")
            return
        }
        val delegates = ctx.inhDelegate().map { InhDelegateEquation(it.child, it.value) }
        bucket[nodeName] = InhEquation(
            attrName = attrName,
            incomingAlias = ctx.alias?.text,
            nodeName = nodeName,
            paramPatterns = ctx.simpleParameterPattern(),
            delegates = delegates,
            span = SourceSpan.of(ctx)
        )
    }
}
