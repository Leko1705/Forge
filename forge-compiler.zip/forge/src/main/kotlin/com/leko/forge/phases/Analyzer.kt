package com.leko.forge.phases

import com.leko.forge.context.Context
import com.leko.forge.parser.ForgeParser
import com.leko.forge.util.Log

/**
 * Orchestrator — javac's `JavaCompiler#compile` analog. Drives the fixed phase
 * pipeline over one parsed root, stopping early if an earlier phase already
 * produced errors that would make later phases meaningless (e.g. no point
 * running completeness checking if node names themselves failed to resolve).
 */
class Analyzer private constructor(private val context: Context) {
    companion object {
        fun getInstance(context: Context): Analyzer =
            context.getServices(Analyzer::class) { Analyzer(context) }
    }

    private val log = Log.instance(context)

    fun analyze(root: ForgeParser.RootContext) {
        // Phase 1: build the symbol table (records, enums, functions, nodes, impls).
        Enter.instance(context).enter(root)
        if (log.hasErrors()) return log.report()

        // Phase 2: register syn/inh declarations and equations.
        AttrEnter.instance(context).enter(root)
        if (log.hasErrors()) return log.report()

        // Phase 3: Rust-trait-style completeness check (every impl satisfies its interface).
        CompletenessChecker.instance(context).check()

        // Phase 4: attribute-dependency circularity check.
        val deps = DependencyGraph.instance(context)
        deps.build()
        deps.checkAcyclic()

        // Phase 5 (extension point): type-check equation/function bodies with
        // ExprTypeChecker.instance(context) here once binding parameter-pattern
        // types into `env` is wired up — left out for now to keep this pass
        // focused, see ExprTypeChecker's doc comment for what's implemented.

        log.report()
    }
}
