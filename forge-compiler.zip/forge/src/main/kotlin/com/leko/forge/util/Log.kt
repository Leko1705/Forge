package com.leko.forge.util

import com.leko.forge.context.Context

enum class Severity { ERROR, WARNING, INFO }

data class Diagnostic(
    val severity: Severity,
    val span: SourceSpan?,
    val code: String,
    val message: String
)

/**
 * Shared diagnostics sink (javac's Log analog). Every phase reports into the same
 * instance so errors from Enter, completeness checking, circularity checking, etc.
 * all accumulate together instead of the caller having to stitch per-phase results
 * back together. Collect-then-report, not throw-on-first — see the earlier design
 * discussion on error handling.
 */
class Log private constructor() {
    companion object {
        fun instance(context: Context): Log =
            context.getServices(Log::class) { Log() }
    }

    private val _diagnostics = mutableListOf<Diagnostic>()
    val diagnostics: List<Diagnostic> get() = _diagnostics

    fun error(span: SourceSpan?, code: String, message: String) {
        _diagnostics += Diagnostic(Severity.ERROR, span, code, message)
    }

    fun warning(span: SourceSpan?, code: String, message: String) {
        _diagnostics += Diagnostic(Severity.WARNING, span, code, message)
    }

    fun hasErrors(): Boolean = _diagnostics.any { it.severity == Severity.ERROR }

    fun report() {
        for (d in _diagnostics.sortedWith(compareBy({ it.span?.startLine ?: 0 }, { it.span?.startCol ?: 0 }))) {
            val loc = d.span?.toString() ?: "?"
            val label = when (d.severity) {
                Severity.ERROR -> "error"
                Severity.WARNING -> "warning"
                Severity.INFO -> "info"
            }
            println("[$loc] $label ${d.code}: ${d.message}")
        }
        if (hasErrors()) {
            println("${diagnostics.count { it.severity == Severity.ERROR }} error(s).")
        }
    }
}
