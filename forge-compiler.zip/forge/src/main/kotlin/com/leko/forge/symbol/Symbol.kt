package com.leko.forge.symbol

import com.leko.forge.types.Type
import com.leko.forge.util.SourceSpan

data class RecordSymbol(
    val name: String,
    val fields: LinkedHashMap<String, Type>,
    val span: SourceSpan
)

data class EnumItemSymbol(val name: String, val params: List<Pair<String, Type>>)

data class EnumSymbol(
    val name: String,
    val items: LinkedHashMap<String, EnumItemSymbol>,
    val span: SourceSpan
)

data class FunctionSymbol(
    val name: String,
    /** null for free functions; non-null for `fun Type.name(...)` receiver functions. */
    val receiver: Type?,
    val params: List<Pair<String, Type>>,
    val returnType: Type,
    val external: Boolean,
    val span: SourceSpan
)

/** An `interface node` declaration — a trait that concrete nodes can implement. */
class InterfaceNodeSymbol(val name: String, val span: SourceSpan)

/** A `node Name(params...)` declaration, possibly implementing one or more interfaces. */
class ConcreteNodeSymbol(val name: String, val span: SourceSpan) {
    var params: List<Pair<String, Type>> = emptyList()
    val implements = mutableSetOf<String>()
}
