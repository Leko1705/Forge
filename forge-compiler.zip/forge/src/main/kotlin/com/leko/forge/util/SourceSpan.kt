package com.leko.forge.util

import org.antlr.v4.runtime.ParserRuleContext

data class SourceSpan(
    val startLine: Int,
    val startCol: Int,
    val endLine: Int,
    val endCol: Int
) {
    companion object {
        fun of(ctx: ParserRuleContext): SourceSpan = SourceSpan(
            ctx.start.line, ctx.start.charPositionInLine,
            ctx.stop?.line ?: ctx.start.line,
            ctx.stop?.charPositionInLine ?: ctx.start.charPositionInLine
        )
    }

    override fun toString(): String = "$startLine:$startCol"
}
