package com.leko.forge.context

import kotlin.reflect.KClass

/**
 * javac-style dependency-injection container: a map from service type to lazily
 * constructed singleton instance. Every phase/service looks up its collaborators
 * through here instead of constructing them directly, so the whole compiler run
 * shares exactly one SymbolTable, one TypeMap, one Log, etc.
 */
class Context {
    private val services = mutableMapOf<KClass<*>, Any>()

    fun <T : Any> get(key: KClass<T>): T? {
        @Suppress("UNCHECKED_CAST")
        return services[key] as T?
    }

    fun <T : Any> getServices(key: KClass<T>, factory: () -> T): T {
        @Suppress("UNCHECKED_CAST")
        return services.getOrPut(key) { factory() } as T
    }

    fun <T : Any> put(key: KClass<T>, value: T) {
        services[key] = value
    }
}
