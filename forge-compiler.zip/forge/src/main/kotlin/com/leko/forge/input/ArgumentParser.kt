package com.leko.forge.input

/** Minimal flag/positional argument parser: `-f a.forge -f b.forge` -> unbound("-f") = [a.forge, b.forge]. */
class ArgumentParser(private val args: Array<String>) {
    fun unbound(vararg flags: String): List<String> {
        val result = mutableListOf<String>()
        var i = 0
        while (i < args.size) {
            if (args[i] in flags) {
                i++
                while (i < args.size && !args[i].startsWith("-")) {
                    result += args[i]
                    i++
                }
            } else {
                i++
            }
        }
        return result
    }
}
