package com.leko.forge.phases

import com.leko.forge.context.Context
import com.leko.forge.parser.ForgeParser
import com.leko.forge.symbol.SymbolTable
import com.leko.forge.types.Type
import com.leko.forge.types.TypeMap
import com.leko.forge.util.Log
import com.leko.forge.util.SourceSpan

/**
 * Best-effort expression type inference — javac's `Attr` phase, scoped down to
 * Forge's expression grammar. Used to type-check equation bodies against their
 * declared attribute type, and to type-check `fun` bodies.
 *
 * Coverage is intentionally partial: the common atoms, arithmetic, comparisons,
 * field/method access, if/else, and list literals are implemented; `match`,
 * `listComprehension`, `contextualized`, `elvis`, `containerAccess`, `concat`,
 * and the bitwise/xor operators are left as TODO extension points rather than
 * guessed at, since getting comprehension/match typing right needs its own
 * design pass (pattern exhaustiveness, accumulator inference) — not something
 * to improvise inline here.
 */
class ExprTypeChecker private constructor(private val context: Context) {
    companion object {
        fun instance(context: Context): ExprTypeChecker =
            context.getServices(ExprTypeChecker::class) { ExprTypeChecker(context) }
    }

    private val symbolTable = SymbolTable.instance(context)
    private val typeMap = TypeMap.instance(context)
    private val log = Log.instance(context)

    /** env: identifier name -> type (bound parameter patterns, inherited-value alias, etc). */
    fun infer(ctx: ForgeParser.ExpressionContext, env: Map<String, Type>): Type = when (ctx) {
        is ForgeParser.IntValueContext -> Type.IntType
        is ForgeParser.FloatValueContext -> Type.FloatType
        is ForgeParser.StringValueContext -> Type.StrType
        is ForgeParser.BoolValueContext -> Type.BoolType
        is ForgeParser.NegationContext -> infer(ctx.expression(), env)
        is ForgeParser.InversionContext -> Type.BoolType
        is ForgeParser.EnclosedContext -> infer(ctx.expression(), env)

        is ForgeParser.IdentifierContext -> env[ctx.text] ?: run {
            log.error(SourceSpan.of(ctx), "E040", "unresolved identifier '${ctx.text}'")
            Type.ErrorType
        }

        is ForgeParser.FieldAccessContext ->
            typeMap.fieldType(infer(ctx.receiver, env), ctx.name.text)

        is ForgeParser.AddSubContext -> {
            val l = infer(ctx.left, env); val r = infer(ctx.right, env)
            if (typeMap.isSameType(l, r)) l else {
                log.error(SourceSpan.of(ctx), "E041", "type mismatch: '$l' vs '$r'")
                Type.ErrorType
            }
        }
        is ForgeParser.MulDivModContext -> {
            val l = infer(ctx.left, env); val r = infer(ctx.right, env)
            if (typeMap.isSameType(l, r)) l else {
                log.error(SourceSpan.of(ctx), "E041", "type mismatch: '$l' vs '$r'")
                Type.ErrorType
            }
        }
        is ForgeParser.EqualityContext -> { infer(ctx.left, env); infer(ctx.right, env); Type.BoolType }
        is ForgeParser.RelationalContext -> { infer(ctx.left, env); infer(ctx.right, env); Type.BoolType }
        is ForgeParser.LogicalAndContext -> { infer(ctx.left, env); infer(ctx.right, env); Type.BoolType }
        is ForgeParser.LogicalOrContext -> { infer(ctx.left, env); infer(ctx.right, env); Type.BoolType }

        is ForgeParser.ListLiteralContext -> {
            val elems = ctx.expression().map { infer(it, env) }
            Type.ListType(elems.firstOrNull() ?: Type.UnknownType)
        }

        is ForgeParser.FunctionCallContext -> {
            symbolTable.functionsNamed(ctx.name.text, receiver = null).firstOrNull()?.returnType ?: run {
                log.error(SourceSpan.of(ctx), "E042", "unresolved function '${ctx.name.text}'")
                Type.ErrorType
            }
        }
        is ForgeParser.MethodCallContext -> {
            val recv = infer(ctx.receiver, env)
            symbolTable.functionsNamed(ctx.name.text, receiver = recv).firstOrNull()?.returnType ?: run {
                log.error(SourceSpan.of(ctx), "E042", "unresolved method '${ctx.name.text}' on '$recv'")
                Type.ErrorType
            }
        }

        is ForgeParser.IfElseContext -> {
            infer(ctx.cond, env)
            val t = infer(ctx.then, env); val e = infer(ctx.alt, env)
            if (typeMap.isSameType(t, e)) t else {
                log.error(SourceSpan.of(ctx), "E043", "if/else branches disagree: '$t' vs '$e'")
                Type.ErrorType
            }
        }

        // TODO: match, listComprehension, contextualized, elvis, containerAccess,
        //       concat, iand/ior/xor/inOp — see class doc.
        else -> Type.UnknownType
    }
}
