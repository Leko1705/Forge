package com.leko.forge.phases

import com.leko.forge.attr.AttributeTable
import com.leko.forge.context.Context
import com.leko.forge.parser.ForgeParser
import com.leko.forge.util.Log
import com.leko.forge.util.SourceSpan
import org.antlr.v4.runtime.tree.ParseTree

/**
 * Phase 4 — javac's `Flow` analog, repurposed for attribute circularity instead
 * of definite-assignment. Builds a dependency graph over every (node, attribute)
 * equation and rejects cycles, since Forge's grammar has no `circular`/fixed-point
 * construct yet: an accidental cycle here would otherwise only surface as infinite
 * recursion at evaluation time.
 *
 * NOTE: reference collection is name-based (does an equation body call an
 * identifier/function/method whose name matches a known attribute name?) rather
 * than fully scope-resolved. This is intentionally conservative — a name match is
 * treated as a possible dependency edge even where it might not actually resolve.
 * Replace with resolved references once Forge has a real name-resolution pass;
 * that pass would also be the natural place to distinguish `circular`-declared
 * attributes (once that construct exists) and route them to fixed-point
 * evaluation instead of being flagged as errors here.
 */
class DependencyGraph private constructor(private val context: Context) {
    companion object {
        fun instance(context: Context): DependencyGraph =
            context.getServices(DependencyGraph::class) { DependencyGraph(context) }
    }

    private val attributeTable = AttributeTable.instance(context)
    private val log = Log.instance(context)

    data class Node(val nodeName: String, val attrName: String)

    private val edges = mutableMapOf<Node, MutableSet<Node>>()
    private val spans = mutableMapOf<Node, SourceSpan>()

    fun build() {
        val knownAttrs = attributeTable.allAttributeNames()

        for ((nodeName, byAttr) in attributeTable.synEquations) {
            for (eq in byAttr.values) {
                val self = Node(nodeName, eq.attrName)
                spans[self] = eq.span
                val refs = collectReferences(eq.body, knownAttrs)
                edges.getOrPut(self) { mutableSetOf() } += refs.map { Node(nodeName, it) }
            }
        }
        for ((attrName, byNode) in attributeTable.inhEquations) {
            for (eq in byNode.values) {
                val self = Node(eq.nodeName, attrName)
                spans[self] = eq.span
                for (delegate in eq.delegates) {
                    val refs = collectReferences(delegate.value, knownAttrs)
                    edges.getOrPut(self) { mutableSetOf() } += refs.map { Node(eq.nodeName, it) }
                }
            }
        }
    }

    private fun collectReferences(tree: ParseTree, knownAttrs: Set<String>): Set<String> {
        val found = mutableSetOf<String>()
        fun visit(t: ParseTree) {
            when (t) {
                is ForgeParser.FunctionCallContext -> if (t.name.text in knownAttrs) found += t.name.text
                is ForgeParser.MethodCallContext -> if (t.name.text in knownAttrs) found += t.name.text
                is ForgeParser.IdentifierContext -> if (t.text in knownAttrs) found += t.text
            }
            for (i in 0 until t.childCount) visit(t.getChild(i))
        }
        visit(tree)
        return found
    }

    /** DFS with a 3-colour recursion-stack marker; reports each distinct simple cycle once. */
    fun checkAcyclic() {
        val white = 0; val gray = 1; val black = 2
        val color = mutableMapOf<Node, Int>()
        val stack = mutableListOf<Node>()

        fun dfs(n: Node) {
            color[n] = gray
            stack += n
            for (next in edges[n].orEmpty()) {
                when (color[next] ?: white) {
                    white -> dfs(next)
                    gray -> {
                        val cycleStart = stack.indexOf(next)
                        val cycle = (stack.subList(cycleStart, stack.size) + next)
                            .joinToString(" -> ") { "${it.nodeName}.${it.attrName}" }
                        log.error(
                            spans[n], "E030",
                            "circular attribute dependency: $cycle " +
                            "(Forge has no 'circular'/fixed-point construct yet — break the cycle or add one)"
                        )
                    }
                    else -> {}
                }
            }
            stack.removeAt(stack.size - 1)
            color[n] = black
        }

        for (n in edges.keys) if ((color[n] ?: white) == white) dfs(n)
    }
}
