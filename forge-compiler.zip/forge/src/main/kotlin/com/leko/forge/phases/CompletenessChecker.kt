package com.leko.forge.phases

import com.leko.forge.attr.AttributeTable
import com.leko.forge.context.Context
import com.leko.forge.symbol.SymbolTable
import com.leko.forge.types.TypeMap
import com.leko.forge.util.Log

/**
 * Phase 3 — the Rust-trait-style completeness check that is Forge's main selling
 * point over plain JastAdd: every `for X impl Y` must provide a `syn`/`inh`
 * equation for each attribute `Y` requires, with a compatible type. Missing or
 * mistyped implementations are reported here at "compile the compiler" time
 * instead of surfacing as a runtime "no equation for this attribute" crash.
 */
class CompletenessChecker private constructor(private val context: Context) {
    companion object {
        fun instance(context: Context): CompletenessChecker =
            context.getServices(CompletenessChecker::class) { CompletenessChecker(context) }
    }

    private val symbolTable = SymbolTable.instance(context)
    private val attributeTable = AttributeTable.instance(context)
    private val typeMap = TypeMap.instance(context)
    private val log = Log.instance(context)

    fun check() {
        for (node in symbolTable.concreteNodes.values) {
            for (ifaceName in node.implements) {
                val requirements = attributeTable.requirements[ifaceName] ?: continue
                for (req in requirements.values) {
                    val provided = attributeTable.synEquations[node.name]?.get(req.attrName)
                    if (provided == null) {
                        log.error(
                            node.span, "E020",
                            "node '${node.name}' does not implement '$ifaceName.${req.attrName}: ${req.attrType}' " +
                            "(required by 'for ${node.name} impl $ifaceName')"
                        )
                        continue
                    }
                    if (!typeMap.isAssignable(provided.attrType, req.attrType)) {
                        log.error(
                            provided.span, "E021",
                            "'${node.name}.${req.attrName}' has type '${provided.attrType}', " +
                            "but '$ifaceName' requires '${req.attrType}'"
                        )
                    }
                }
            }
        }
    }
}
