package com.leko.forge

import com.leko.forge.context.Context
import com.leko.forge.input.ArgumentParser
import com.leko.forge.parse.parseForge
import com.leko.forge.phases.Analyzer
import java.io.File

fun main(args: Array<String>) {
    val argParser = ArgumentParser(args)
    val files = argParser.unbound("-f", "--f").map { File(it) }

    // One Context per compilation run — every service registered into it
    // (Log, SymbolTable, TypeMap, AttributeTable, ...) is shared across all
    // files below, matching javac's one-Context-per-compile-task model.
    val context = Context()

    for (file in files) {
        val ast = file.parseForge()
        val analyzer = Analyzer.getInstance(context)
        analyzer.analyze(ast)
    }
}
