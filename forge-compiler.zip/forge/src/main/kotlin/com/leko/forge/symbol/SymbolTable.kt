package com.leko.forge.symbol

import com.leko.forge.context.Context
import com.leko.forge.types.Type

/**
 * javac's `Symtab` analog: the registry of everything that has been declared
 * (records, enums, functions, interface nodes, concrete nodes, impl relations).
 * Populated by the Enter phase, then read by every later phase. Kept separate
 * from TypeMap on purpose — this answers "what exists and where", TypeMap
 * answers "what can I do with a Type".
 */
class SymbolTable private constructor() {
    companion object {
        fun instance(context: Context): SymbolTable =
            context.getServices(SymbolTable::class) { SymbolTable() }
    }

    val records = linkedMapOf<String, RecordSymbol>()
    val enums = linkedMapOf<String, EnumSymbol>()
    val functions = mutableListOf<FunctionSymbol>() // list, not map: functions can be overloaded
    val interfaces = linkedMapOf<String, InterfaceNodeSymbol>()
    val concreteNodes = linkedMapOf<String, ConcreteNodeSymbol>()

    fun isNodeName(name: String): Boolean =
        interfaces.containsKey(name) || concreteNodes.containsKey(name)

    fun functionsNamed(name: String, receiver: Type?): List<FunctionSymbol> =
        functions.filter { it.name == name && it.receiver == receiver }
}
