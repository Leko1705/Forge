package com.leko.forge.attr

import com.leko.forge.parser.ForgeParser
import com.leko.forge.types.Type
import com.leko.forge.util.SourceSpan

/** `syn Iface.attr: T` — an abstract requirement every implementer of Iface must satisfy. */
data class SynRequirement(val ifaceName: String, val attrName: String, val attrType: Type, val span: SourceSpan)

/** `syn Node(pattern...).attr: T = expr` — a concrete synthesized-attribute equation. */
data class SynEquation(
    val nodeName: String,
    val paramPatterns: List<ForgeParser.SimpleParameterPatternContext>,
    val attrName: String,
    val attrType: Type,
    val body: ForgeParser.ExpressionContext,
    val span: SourceSpan
)

/** `inh attr: T = expr` — declares an inherited attribute and its root/bootstrap value. */
data class InhDeclaration(
    val attrName: String,
    val attrType: Type,
    val init: ForgeParser.ExpressionContext,
    val span: SourceSpan
)

/** One `child -> value` line inside an `inh ... -> Node(...) { ... }` block. */
data class InhDelegateEquation(val child: ForgeParser.ExpressionContext, val value: ForgeParser.ExpressionContext)

/** `inh attr(alias) -> Node(pattern...) { delegate* }` — how Node pushes attr down to its children. */
data class InhEquation(
    val attrName: String,
    /** name the incoming inherited value is bound to; null means it was `_` (discarded). */
    val incomingAlias: String?,
    val nodeName: String,
    val paramPatterns: List<ForgeParser.SimpleParameterPatternContext>,
    val delegates: List<InhDelegateEquation>,
    val span: SourceSpan
)
