package com.leko.forge.attr

import com.leko.forge.context.Context

/**
 * Registry of every syn/inh declaration and equation in the program. Populated
 * by the AttrEnter phase; consumed by CompletenessChecker (interface conformance)
 * and DependencyGraph (circularity checking).
 */
class AttributeTable private constructor() {
    companion object {
        fun instance(context: Context): AttributeTable =
            context.getServices(AttributeTable::class) { AttributeTable() }
    }

    /** interfaceName -> attrName -> requirement */
    val requirements = linkedMapOf<String, LinkedHashMap<String, SynRequirement>>()

    /** nodeName -> attrName -> equation. One entry per (node, attr): a second write is a coherence error. */
    val synEquations = linkedMapOf<String, LinkedHashMap<String, SynEquation>>()

    val inhDeclarations = linkedMapOf<String, InhDeclaration>()

    /** attrName -> nodeName -> equation */
    val inhEquations = linkedMapOf<String, LinkedHashMap<String, InhEquation>>()

    fun allAttributeNames(): Set<String> =
        requirements.values.flatMap { it.keys }.toSet() +
        synEquations.values.flatMap { it.keys }.toSet() +
        inhDeclarations.keys
}
