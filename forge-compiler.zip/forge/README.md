# Forge compiler — javac-style Context/phase architecture

Drop `src/main/kotlin/com/leko/forge/**` into your existing Forge project
(package layout matches your current `build.gradle.kts` / `com.leko.forge.*`).
Assumes the ANTLR grammar is generated into `com.leko.forge.parser`
(`ForgeLexer`, `ForgeParser`) as set up earlier.

## Pipeline (mirrors javac's phase sequence)

| # | Service | javac analog | Job |
|---|---|---|---|
| — | `context/Context` | `Context` | DI container: one instance per compile run, holds every service below as a lazily-built singleton |
| — | `util/Log` | `Log` | shared diagnostics sink — collect-then-report, not throw-on-first |
| — | `types/Type`, `types/TypeMap` | `Type`, `Types` | type representation + operations (resolve grammar `type` nodes, assignability, field lookup) |
| — | `symbol/Symbol`, `symbol/SymbolTable` | `Symbol`, `Symtab` | what exists: records, enums, functions, interface nodes, concrete nodes, impl relations |
| — | `attr/Attribute`, `attr/AttributeTable` | — (Forge-specific) | registry of `syn`/`inh` declarations and equations |
| 1 | `phases/Enter` | `Enter` | populate `SymbolTable` from the parse tree (two sub-passes: names, then bodies, so forward references resolve) |
| 2 | `phases/AttrEnter` | `MemberEnter` | populate `AttributeTable`; enforces one-equation-per-(node,attr) coherence |
| 3 | `phases/CompletenessChecker` | — (Forge-specific) | the Rust-trait-style check: every `for X impl Y` must provide everything `Y` requires, with a compatible type |
| 4 | `phases/DependencyGraph` | `Flow` (repurposed) | builds the attribute dependency graph and rejects accidental cycles (name-based reference collection — see class doc for the caveat) |
| — | `phases/ExprTypeChecker` | `Attr` (partial) | best-effort expression type inference; covers the common expression forms, leaves `match`/comprehensions/etc. as explicit TODOs |
| — | `phases/Analyzer` | `JavaCompiler#compile` | orchestrates the above in order, short-circuiting after phases whose errors would make later phases meaningless |
| — | `parse/ParseForge` | — | `File.parseForge()`: the only place ANTLR is invoked directly |

## What's deliberately left as a stub

- **`ExprTypeChecker`**: only the common expression forms are implemented
  (literals, arithmetic, comparisons, field/method access, if/else, list
  literals). `match`, `listComprehension`, `contextualized`, `elvis`,
  `containerAccess`, `concat`, and the bitwise/xor operators are TODO —
  each needs its own small design pass rather than a guessed implementation.
- **`DependencyGraph`** resolves references by *name*, not full scope
  resolution — good enough to catch obvious cycles now, but should be
  swapped for resolved references once Forge has a real name-resolution pass.
- **No `circular` construct** exists in the current grammar, so any cycle
  found by `DependencyGraph` is reported as an error. Once `circular` is
  added to the grammar, this phase is the natural place to route
  `circular`-marked attributes to fixed-point evaluation instead.
- **No codegen phase** — `TypeMap`/`SymbolTable`/`AttributeTable` are built
  so that a `Lower`/`Gen`-equivalent phase (target-language emission) can be
  added later, consuming the same services rather than re-deriving types.

## Wiring into your existing `build.gradle.kts`

No changes needed — this assumes the `antlr` plugin setup and
`src/main/antlr/com/leko/forge/parser/{ForgeLexer,ForgeParser}.g4` layout
already in place from earlier in this conversation.
